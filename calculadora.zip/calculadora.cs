﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Calculadora2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtNum1_TextChanged(object sender, EventArgs e)
        {
           
        }
        private void btnSoma_Click(object sender, EventArgs e)
        {
            int num1 = int.Parse(txtNum1.Text);
            int num2 = int.Parse(txtNum2.Text);
            float resultado;

            resultado = num1 + num2;
            MessageBox.Show("soma: " + resultado);
        }

        private void btnSub_Click(object sender, EventArgs e)
        {
            int num1 = int.Parse(txtNum1.Text);
            int num2 = int.Parse(txtNum2.Text);
            float resultado;

            resultado = num1 - num2;
            MessageBox.Show("subtracao: " + resultado);

        }

        private void btnDiv_Click(object sender, EventArgs e)
        {
            int num1 = int.Parse(txtNum1.Text);
            int num2 = int.Parse(txtNum2.Text);
            float resultado;

            resultado = num1 / num2;
            MessageBox.Show("divisao: " + resultado);
        }

        private void btnMult_Click(object sender, EventArgs e)
        {
            int num1 = int.Parse(txtNum1.Text);
            int num2 = int.Parse(txtNum2.Text);
            float resultado;

            resultado = num1 * num2;
            MessageBox.Show("multiplicacao:" + resultado);
        }
    }
}
